variable1=2100
print(variable1)
print(type(variable1))

variable1="Hola"
print(variable1)
print(type(variable1))

variable2=12.25
print(variable2)
print(type(variable2))

variable2=True
print(variable2)
print(type(variable2), end="")

print("Hola mundo soy Hector)")

print("Ingrese suu nombre:")
texto= input()
print(texto + "Hola")

print("hola mundo")
print("soy hector")

#La diferecia entre print y print end es que enm print se escribe en lineas separadas, pero con print end se escribe seguido.

print("Hola mundo", end="")
print("soy Hector", end="")